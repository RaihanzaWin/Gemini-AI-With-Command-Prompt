============================================================
           GEMINI AI CMD - BY [ME]
============================================================

[ENGLISH VERSION]

This is a lightweight Gemini AI Assistant running directly in your CMD.
Features: Multi-API Support (5 Keys), Chat History (Auto-Save), and Rich Text.

--- HOW TO USE ---

1. INSTALL PYTHON:
   Download and install Python from https://www.python.org/
   IMPORTANT: Check "Add Python to PATH" during installation.

2. INSTALL REQUIREMENTS:
   Open your Terminal/CMD and type:
   pip install -U google-generativeai

5. RUN THE PROGRAM:
   Double-click 'BukaAI.bat' to start chatting.

------------------------------------------------------------

[VERSI INDONESIA]

Ini adalah asisten AI Gemini ringan yang jalan langsung di CMD kamu.
Fitur: Support 5 API Key, Simpan Chat Otomatis, dan Teks Berwarna.

--- CARA PENGGUNAAN ---

1. INSTAL PYTHON:
   Download dan instal Python di https://www.python.org/
   PENTING: Centang "Add Python to PATH" saat instalasi.

2. INSTAL BAHAN (LIBRARY):
   Buka CMD dan ketik perintah:
   pip install -U google-generativeai

3. JALANKAN PROGRAM:
   Klik 2x pada file 'BukaAI.bat' untuk mulai ngobrol.

============================================================