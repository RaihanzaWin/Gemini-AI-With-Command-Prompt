import os
import google.generativeai as genai
import json
from datetime import datetime

# ==========================================
# 1. MASUKKAN 5 API KEY KAMU DI SINI
# ==========================================
DAFTAR_KUNCI = [
    "AIzaSyCwa9SLZoofKkpcP7rlg_88G5DSEuB8rc8",
    "AIzaSyD7LqXzJWguOJQ7x6be5lvB618gIPs9QIM",
    "AIzaSyCzTKt7iPYCcljqmJHHzaZTl42kK7rpmq4",
    "AIzaSyApqp3Bkem4F9PM7B0ZwXLoYrmwb0Cxf9w",
    "AIzaSyAivCWCvQWsWKdni3biuIdO0M6gZKCccAE"
]

# Kode Warna biar keren
BOLD = '\033[1m'
CYAN = '\033[96m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
RESET = '\033[0m'

def tampilkan_teks_kaya(teks):
    parts = teks.split('**')
    hasil = ""
    for i, part in enumerate(parts):
        if i % 2 == 1: hasil += BOLD + part + RESET
        else: hasil += part
    return hasil

def chat_gemini():
    os.system('') # Biar warna muncul di Windows
    folder = "saves/gemini"
    if not os.path.exists(folder): os.makedirs(folder)
    
    indeks_kunci = 0
    
    def inisialisasi_model(idx):
        try:
            genai.configure(api_key=DAFTAR_KUNCI[idx])
            # Auto-detect model biar gak 404
            available_models = [m.name for m in genai.list_models() if 'generateContent' in m.supported_generation_methods]
            target = 'models/gemini-1.5-flash'
            if target not in available_models:
                target = available_models[0]
            return genai.GenerativeModel(model_name=target)
        except Exception as e:
            print(f"Gagal konek kunci ke-{idx+1}: {e}")
            return None

    # --- MENU SELECT ---
    os.system('cls')
    files = [f for f in os.listdir(folder) if f.endswith(".json")]
    print(f"{CYAN}======================================={RESET}")
    print(f"{BOLD}    GEMINI AI - MULTI API SYSTEM{RESET}")
    print(f"{CYAN}======================================={RESET}")
    print(f"{YELLOW} 0. [ + ] Obrolan Baru{RESET}")
    for i, f in enumerate(files, 1):
        print(f" {i}. {f.replace('.json', '')}")
    print(f"{CYAN}======================================={RESET}")
    
    pilih = input(f"{BOLD}Pilih nomor:{RESET} ")
    history_data = []
    
    if pilih == "0":
        nama = input(f"\n{YELLOW}Nama Chat Baru:{RESET} ") or datetime.now().strftime("%H%M")
        file_path = f"{folder}/{nama}.json"
    else:
        try:
            file_path = f"{folder}/{files[int(pilih)-1]}"
            with open(file_path, "r") as f:
                history_data = json.load(f)
        except:
            print("Pilihan salah!"); return

    # --- MULAI CHAT ---
    os.system('cls')
    model = inisialisasi_model(indeks_kunci)
    if not model:
        print("Gagal memulai model. Cek API Key!"); return

    print(f"{GREEN}Terhubung! (Kunci #{indeks_kunci + 1}){RESET}")
    print(f"Ketik {YELLOW}'exit'{RESET} untuk simpan.\n")

    # Tampilkan history lama
    formatted_history = []
    for h in history_data[-15:]: # Ambil 15 chat terakhir biar irit
        warna = GREEN if h["role"] == "model" else BOLD
        nama_role = "(Gemini)" if h["role"] == "model" else "User"
        print(f"{warna}{nama_role}>{RESET} {tampilkan_teks_kaya(h['content'])}\n")
        formatted_history.append({"role": h["role"], "parts": [h["content"]]})
    
    chat = model.start_chat(history=formatted_history)

    while True:
        tanya = input(f"{BOLD}User>{RESET} ")
        if tanya.lower() == "exit": break
        if not tanya: continue
        
        try:
            response = chat.send_message(tanya)
            clean_text = tampilkan_teks_kaya(response.text)
            print(f"\n{GREEN}(Gemini){RESET}\n{clean_text}\n")
            
            history_data.append({"role": "user", "content": tanya})
            history_data.append({"role": "model", "content": response.text})
            with open(file_path, "w") as f:
                json.dump(history_data, f, indent=4)
                
        except Exception as e:
            if "429" in str(e) and indeks_kunci < len(DAFTAR_KUNCI) - 1:
                indeks_kunci += 1
                print(f"\n{YELLOW}[!] Kunci #{indeks_kunci} limit, pindah ke #{indeks_kunci+1}...{RESET}")
                genai.configure(api_key=DAFTAR_KUNCI[indeks_kunci])
                model = genai.GenerativeModel('models/gemini-1.5-flash')
                chat = model.start_chat(history=formatted_history)
                # Ulangi kirim
                response = chat.send_message(tanya)
                print(f"\n{GREEN}(Gemini){RESET}\n{tampilkan_teks_kaya(response.text)}\n")
            else:
                print(f"\n{YELLOW}Error:{RESET} {e}")
                break

if __name__ == "__main__":
    chat_gemini()